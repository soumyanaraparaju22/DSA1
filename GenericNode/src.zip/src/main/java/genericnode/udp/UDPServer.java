package genericnode.udp;
import java.io.*;
import java.io.IOException;
import java.net.*;
import java.sql.Blob;
import java.util.*;
import java.util.AbstractMap.SimpleEntry;
public class UDPServer {
    
    public  void server(byte[] sendData,
    String addr,
    int sendport,
    byte[] receiveData,
    int recvport)
    {
        try{
        DatagramSocket serverSocket = new DatagramSocket();
        DatagramSocket clientSocket = new DatagramSocket();
  System.out.println("SERVER IS READY");
        DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length,InetAddress.getByName(addr), recvport);
                  serverSocket.receive(receivePacket);
                  String sentence = new String( receivePacket.getData());
                  System.out.println("RECEIVED: " + sentence);
                  DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, InetAddress.getByName(addr), sendport);
                  serverSocket.send(sendPacket);

    
            
    }
    catch(SocketException e)
    {
        e.printStackTrace();
    }
    catch(IOException e)
    {
        e.printStackTrace();
    }
}

}
