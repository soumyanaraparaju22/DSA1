package genericnode.udp;

import java.io.*;
import java.io.IOException;
import java.net.*;
import java.sql.Blob;
import java.util.*;
import java.util.AbstractMap.SimpleEntry;

public class UDPClient {

  public void connection(
    byte[] sendData,
    String addr,
    int sendport,
    byte[] receiveData,
    int recvport
  )
    throws IOException {
    try {
      DatagramSocket serverSocket = new DatagramSocket();
      DatagramSocket clientSocket = new DatagramSocket();
    System.out.println("CLIENT IS READY");
      DatagramPacket sendPacket = new DatagramPacket(
        sendData,
        sendData.length,
        InetAddress.getByName(addr),
        sendport
      );
      clientSocket.send(sendPacket);

      DatagramPacket receivePacket = new DatagramPacket(
        receiveData,
        receiveData.length,
        InetAddress.getByName(addr),
        recvport
      );
      clientSocket.receive(receivePacket);

      String modifiedSentence = new String(receivePacket.getData());
      System.out.println("FROM SERVER:" + modifiedSentence);
    } catch (SocketException e) {
      e.printStackTrace();
    }
  }
}
