package genericnode.RMI;
import java.rmi.registry.Registry;


import java.rmi.registry.LocateRegistry;

import java.rmi.server.UnicastRemoteObject;
import java.util.AbstractMap;

import java.util.AbstractMap.SimpleEntry;

import genericnode.Operations;

import java.util.ArrayList;
        
public class RMIServer implements Hello {
   
       ArrayList <AbstractMap.SimpleEntry<String,String>> list =new ArrayList<>();
    public RMIServer() {}

    public String sayHello(String address, String cmd,String Key,String value ) {
       String str="";
       if(cmd=="put" && Key!="" && value!="" ){
        Operations ops=new Operations();
        str=ops.put(Key, value);
      
       
       }
       else if (cmd == "get" ){
        Operations ops=new Operations();
        str=ops.get(Key);

        }
       else if(cmd == "del"){
        Operations ops=new Operations();
        str=ops.del(Key);

       }
       else if(cmd=="store"){
        Operations ops=new Operations();
        str=ops.store();

       }
       return str;
    
    }
    
   public  static void server() {
        
        try {

            
            RMIServer obj = new RMIServer();
           Hello stub = (Hello) UnicastRemoteObject.exportObject(obj, 0);
            // System.setProperty("java.rmi.server.hostname","127.0.1.0");
            // Bind the remote object's stub in the registry
           LocateRegistry.createRegistry(1099);
            Registry registry = LocateRegistry.getRegistry();
            registry.bind("Hello", stub);

            System.out.println("Server ready");
        } catch (Exception e) {
            System.out.println("Server exception: " + e.toString());
            e.printStackTrace();
        }
    }
}