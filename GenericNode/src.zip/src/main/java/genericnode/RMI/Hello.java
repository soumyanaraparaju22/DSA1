package genericnode.RMI;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.AbstractMap.SimpleEntry;

public interface Hello extends Remote {
    String sayHello(String address , String cmd, String Key, String value ) throws RemoteException;
}