package genericnode.RMI;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.AbstractMap.SimpleEntry;

public class RMIClient {

    private RMIClient() {}

    public static void client(String address , String cmd, String Key, String value) {


       
        try {
            

         // System.setProperty("java.rmi.server.hostname","127.0.1.0");
          // LocateRegistry.createRegistry(1099);
            Registry registry = LocateRegistry.getRegistry(1099);
            Hello stub = (Hello)registry.lookup("Hello");

            String response = stub.sayHello(address,cmd,Key,value);
            System.out.println("response: " + response);
        } catch (Exception e) {
            System.out.println("Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}